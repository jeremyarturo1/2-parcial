#Crear una clase que administre una libreta de conctatos. Se debe almacenar el nombre de la persona, teléfono, mail y dirección

#Debe mostrar un menú con las siguientes opciones

#1 crear conctatos en la agenda

#2 listado de conctatos

#3 buscar ingresando el nombre de la persona

#4 modificación de su teléfono, mail o dirección

#5 finalizar programa

import os
from peewee import *
from prettytable import PrettyTable


db_conection = SqliteDatabase('contactos.db')
db_conection.connect()

class contactos(Model):
    nombre = CharField()
    telefono = CharField()
    mail = CharField(null = False)
    direccion = CharField(null = False)
    class Meta:
        database = db_conection

db_conection.create_tables([contactos])


menu = """
>>>>MENÚ<<<<
1-crear conctatos en la agenda
2-listado de conctatos
3-buscar ingresando el nombre de la persona
4-modificación de su teléfono, mail o dirección
5-finalizar programa"""


def clean():
    os.system('cls')


def agregar():
    clean()
    cont = contactos()
    cont.nombre = input("Digite el nombre del contacto: ")
    cont.telefono = input("Digite el número de contacto: ")
    cont.mail = input("Digite el correo del contacto (opcional): ")
    cont.direccion = input("Digite la direccion del contacto (opcional): ")
    clean()
    cont.save()
    print("Datos guardados")
    input("Pulse enter para continuar: ")


def mostrar():
    clean()
    mostrar = PrettyTable()
    mostrar.field_names = ["Id", "Nombre", "Teléfono", "Correo", "Direccion"]
    for cont in contactos.select():
        mostrar.add_row([cont.id, cont.nombre, cont.telefono,cont.mail, cont.direccion])
    print(mostrar)
    input("Pulse enter para continuar: ")


def buscar():
    clean()
    mostrar = PrettyTable()
    mostrar.field_names = ["Nombre"]
    for cont in contactos.select():
        mostrar.add_row([cont.nombre])
    print(mostrar)
    nom = input("Ingrese el nombre de la persona que desea ver: ")
    if nom == "":
        return False
    persona = contactos.select().where(contactos.nombre == nom).get()
    busqueda = f"""
Nombre: {persona.nombre}
Teléfono: {persona.telefono}
Correo: {persona.mail}
Dirección: {persona.direccion}
"""
    print(busqueda)
    input("Pulse enter para continuar: ")


def cambiar_dato(lugar, dato):
    print("En el campo " + lugar + " está: " + dato)
    nuevo_dato = input("Digite un nuevo valor o deje en blanco para continuar: ")
    if nuevo_dato == "":
        return dato
    else:
        return nuevo_dato


def modificar():
    clean()
    mostrar = PrettyTable()
    mostrar.field_names = ["Id","Nombre"]
    for cont in contactos.select():
        mostrar.add_row([cont.id, cont.nombre])
    print(mostrar)
    nom = input("Ingrese el nombre de la persona que desea ver: ")
    if nom == "":
        return False
    persona = contactos.select().where(contactos.nombre == nom).get()
    persona.telefono = cambiar_dato("telefono", persona.telefono)
    persona.mail = cambiar_dato("correo", persona.mail)
    persona.direccion = cambiar_dato("direccion", persona.direccion)
    clean()
    persona.save()
    print("Datos modificados")
    input("Pulse enter para continuar: ")


programa = True


while programa:
    clean()
    print(menu)
    opcion = input("DIGITE EL NUMERO DE LA ACCION QUE DESEA REALIZAR: ")
    if opcion == "1":
        agregar()
    elif opcion == "2":
        mostrar()
    elif opcion == "3":
        buscar()
    elif opcion == "4":
        modificar()
    elif opcion == "5":
        input("Pulse enter para salir: ")
        programa = False
    else:
        input("Opcion incorrecta, pulse enter para volver a intentar: ")